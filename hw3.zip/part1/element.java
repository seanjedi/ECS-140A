public abstract class Element {

    public Element next = null;
    
    public Element() {
        
    }
    
}



