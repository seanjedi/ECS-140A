public class MyInteger extends Element {
    
    private int myInt;
    
    public MyInteger() {
        myInt = 0;
    }
    
    public int Get() {
        return myInt;
    }
    
    public void Set(int val) {
        myInt = val;
    }


}


