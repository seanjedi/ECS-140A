public class Sequence extends Element {

    private Sequence seq;
    
    private Element fEl;
    private int length;
    
    public Sequence() {
        seq = new Sequence();
        fEl = null;
        length = 0;
    }
    
    
    
}

