

public class Sequence extends Element {
    
    private Element data;
    private Sequence next;
    private boolean isHead;
    
    public Sequence() {
        data = null;
        next = null;
        isHead = false;
    }
    
    public void Print() {
        if(isHead) {
            System.out.print("[");
        }
            Print2();
        if(isHead) {
            System.out.print(" ]");
        }
        }
    
    public void Print2() {
        if(length() == 1) {
            System.out.print(" ");
            data.Print();
        }
        else if(next != null) {
            System.out.print(" ");
data.Print();
            next.Print2();
        }
        
        
    }
    
    public Element first() {
        return data;
    }
    
    public Sequence rest() {
        return next;
    }
    
    public int length() {
        if(next != null) {
            return next.length() + 1;
        }
        return 0;
    }
    
    public void add(Element elm, int pos) {
        if(pos < 0 || pos > length()) {
            System.out.println("Out of bounds");
            System.exit(1);
        }
        if(length() == 0) {
            isHead = true;
            next = new Sequence();
            data = elm;
        }
        else if(pos == 0) {
            Sequence s = new Sequence();
            s.data = this.data;
            s.next = this.next;
            next = s;
            data = elm;
        } 
        else {
        Sequence s = next;
        Sequence t = this;
        for(int i = 0; i < pos-1; i++) {
            t = s;
            s = s.next;
        }
        if(s.next == null) {
        s.next = new Sequence();
        s.next.data = data;
        s.data = elm;
        }
        else {
            t.next = new Sequence();
            t.next.data = elm;
            t.next.next = s;
        }
        }
    }
    
    public void delete(int pos) {
        if(pos < 0 || pos > length()) {
            System.out.println("Out of bounds");
            System.exit(1);
        }
        if(length() == 0){
            //do nothing
        } else if(pos == 0){ 
            data = next.data;
            next = next.next;
        } else {
            Sequence s = next;
            Sequence t = this;
            for(int i = 0; i < pos-1; i++) {
                t = s;
                s = s.next;
            }
            if(s.next == null) {
                t.next = null;
            }
            else {
                t.next = s.next;
            }
        }
    }






public Element index(int pos) {
        if(pos < 0 || pos > length()) {
            System.out.println("Out of bounds");
            System.exit(1);
        }
        if(pos == 0) {
            return data;
        }
        Sequence s = next;
        Element d  = s.data;
        int i = 0;
        for(i = 0; i < pos; i++) {
            d = s.data;
            s = s.next;
            
        }
        return d;
    }
    
public Sequence flatten() {
        Sequence ret = new Sequence();
        Sequence x = new Sequence();
        x.data = data;
        x.next = next;
        while(x.next != null) {
            if(x.data instanceof Sequence) {
                    ret = (flatten2(((Sequence)(x.data)),ret));
            }
            else {
                ret.add(x.data, ret.length());
            }
            x = x.next;
        }
        return ret;
        
    
    }
    
    public Sequence flatten2(Sequence x, Sequence ret) {
        while(x.next != null) {
            if(x.data instanceof Sequence) {
                if(((Sequence)(x.data)).length() > 1) {
                ret = (flatten2(((Sequence)(x.data)),ret));
                }
                else {
                    ret.add(((Sequence)(x.data)).data, ret.length());                    
                }
            }
            else {
                Element l = x.data;
                ret.add(l, ret.length());
            }
            x = x.next;            
        }
        return ret;
    }
    


    


    
        public Sequence copy() {
        Sequence ret = new Sequence();
        Element el = data;
        ret.add(data, 0);
        Sequence t = next;
        Element l;
        for(int i = 0; i < length() - 1; i++) {
            l = t.data;
            if(t.data instanceof MyChar) {
                MyChar c = new MyChar();
                c.Set(((MyChar)t.data).Get());
                l = c;
            }
            else if(t.data instanceof MyInteger) {
                MyInteger c = new MyInteger();
                c.Set(((MyInteger)t.data).Get());
                l = c;
            }
            t = t.next;
            ret.add(l, i+1);
        }
        return ret;
    }
}

