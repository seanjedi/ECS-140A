
public class Pair {

	public MyChar key;
	public Element value;
	
	//Empty Constructor
	public Pair() {
		key = new MyChar();
		value = null;	
	}
	
	public Pair(MyChar c, Element e) {
		key = c;
		value = e;
	}
	
	//Pair print rules
	public void Print() {
		System.out.print("(");
		key.Print();
		System.out.print(" ");
		value.Print();
		System.out.print(")");
	}
	
}
