//Basically Sequence Iterator for maps
public class MapIterator {
	private int iterator;
	private Map map;
	public Pair ret;
	
	public MapIterator(int pos, Map M){
    	map = M;
    	iterator = pos;
	}

	public boolean equal (MapIterator other) {
    	return(this.iterator == other.iterator);
	}
	public MapIterator advance() {
    	this.iterator = ++iterator;
    	return(this);
	}
	public Pair get() {
    	ret = map.index(iterator);
    	return(ret);
	}
}
