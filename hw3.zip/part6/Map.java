//Basically sequence with some modifications
public class Map {
	
	//stores a Pair and a Map, like how a Sequence object does
	public Pair data;
	public Map next;
	//if is the first map
	private boolean isHead;
	
	public Map() {
		data = new Pair();
		next = null;
		isHead = false;
	}
	
	
	public void Print() {
		if(isHead) {
			System.out.print("[");
		}
			Print2();
		if(isHead) {
			System.out.print(" ]");
		}
		}
	
	//for maps inside of maps
	public void Print2() {
		if(length() == 1) {
			System.out.print(" ");
			data.Print();
		}
		else if(next != null) {
			System.out.print(" ");
			data.Print();
			next.Print2();
		}
		
		
	}

	//return number of pairs in map recursively
	public int length() {
		if(next != null) {
			return next.length() + 1;
		}
		return 0;
	}
	
	//add a pair
	//if same key, adds it after
	//create current map, next map, create new map in between current and current.next
	public void add(Pair elm) {
		if(length() == 0) {
			isHead = true;
			next = new Map();
			data = elm;
		} 
		else {
		Map s = next;
		Map t = this;
		//could probably have a better base case for loop
		for(int i = 0; i < length(); i++) {
			//since char works with < we can use, otherwise would have to redefine MyChar's .CompareTo and .equals
			if((elm.key).Get() < t.data.key.Get()) {
				//break out
				i = length();
			}
			else {
			t = s;
			s = s.next;
			}
		}
		t.next = new Map();
		t.next.data = t.data;
		t.next.next = s;
		t.data = elm;
		
		}	
	}
	
	//same as sequence index just modified for maps
	public Pair index(int pos) {
		if(pos < 0 || pos > length()) {
			System.out.println("Out of bounds");
			System.exit(1);
		}
		if(pos == 0) {
			return data;
		}
		Map s = next;
		Pair d  = s.data;
		int i = 0;
		for(i = 0; i < pos; i++) {
			d = s.data;
			s = s.next;
			
		}
		return d;
	}
	

	//same as sequence copy() just modified for maps
	public Map copy() {
	Map ret = new Map();
	Pair el = data;
	ret.add(data);
	Map t = next;
	Element l;
	for(int i = 0; i < length() - 1; i++) {
		l = t.data.value;
		Pair c = new Pair();
		c.key.Set(t.data.key.Get());
		c.value = l;
		t = t.next;
		ret.add(c);
	}
	return ret;
}
	//based it on Test4.java's loop
	//iterate through until found, return iterator pointing to first found (so duplicate keys dont matter)
	//if no found, iterator is pointing to the end
	public MapIterator find(MyChar key) {
		MapIterator mp;
		Pair p;
		for (mp = begin(); !mp.equal(end()); mp.advance()) {
			   p = mp.get();
			   if(p.key.Get() == key.Get()) {
				   return mp;
			   }
			}
		return mp;
	}
	

	//same as sequence begin
	  public MapIterator begin(){
		
		  return(new MapIterator(0, copy()));
		
	  }

		
	  //same as sequence end
	  public MapIterator end(){
		
		  return(new MapIterator(length(), copy()));
		
	  }
	
	

	

}







