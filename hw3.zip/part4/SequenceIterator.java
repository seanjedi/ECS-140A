class SequenceIterator {
    private int iterator;
    private Sequence sequence;
    public Element ret;
    public SequenceIterator(int pos, Sequence S){
        sequence = S;
        iterator = pos;
    }

    public boolean equal (SequenceIterator other) {
        return(this.iterator == other.iterator);
    }
    public SequenceIterator advance() {
        this.iterator = ++iterator;
        return(this);
    }
    public Element get() {
        ret = sequence.index(iterator);
        return(ret);
    }
}

