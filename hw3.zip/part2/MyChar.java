public class MyChar extends Element {

    private char myCh;
    
    public MyChar() {
        myCh = '0';
    }
    
    public char Get() {
        return myCh;
    }
    
    public void Set(char val) {
        myCh = val;
    }
    
    public void Print() {
        System.out.print("\'" + myCh + "\'");
    }
    
}



