public class MyInteger extends Element {
    
    private Integer myInt;
    
    public MyInteger() {
        myInt = 0;
    }
    
    public int Get() {
        return myInt;
    }
    
    public void Set(int val) {
        myInt = val;
    }

    public void Print() {
        System.out.print(myInt);
    }

}




