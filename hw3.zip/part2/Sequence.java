

public class Sequence extends Element {
    
    private Element data;
    private Sequence next;
    private boolean isHead;
    
    public Sequence() {
        data = null;
        next = null;
        isHead = false;
    }
    
    public void Print() {
            System.out.print("[");
        Print2();
            System.out.print(" ]");
    }
    
    public void Print2() {
        if(length() == 1) {
            System.out.print(" ");
            data.Print();
        }
        else if(next != null) {
            System.out.print(" ");
            data.Print();
            next.Print2();
        }
        
        
    }
    
    public Element first() {
        return data;
    }
    
    public Sequence rest() {
        return next;
    }
    
    public int length() {
        if(next != null) {
            return next.length() + 1;
        }
        return 0;
    }
    
    public void add(Element elm, int pos) {
        if(pos < 0 || pos > length()) {
            System.out.println("Out of bounds");
            System.exit(1);
        }
        if(length() == 0) {
            isHead = true;
            next = new Sequence();
            data = elm;
        }
        else if(pos == 0) {
            Sequence s = new Sequence();
            s.data = this.data;
            s.next = this.next;
            next = s;
            data = elm;
        } 
        else {
        Sequence s = next;
        Sequence t = this;
        for(int i = 0; i < pos-1; i++) {
            t = s;
            s = s.next;
        }
        if(s.next == null) {
        s.next = new Sequence();
        s.next.data = data;
        s.data = elm;
        }
        else {
            t.next = new Sequence();
            t.next.data = elm;
            t.next.next = s;
        }
        }
    }
    
    public void delete(int pos) {
        if(pos < 0 || pos > length()) {
            System.out.println("Out of bounds");
            System.exit(1);
        }
        if(length() == 0){
            //do nothing
        } else if(pos == 0){ 
            data = next.data;
            next = next.next;
        } else {
            Sequence s = next;
            Sequence t = this;
            for(int i = 0; i < pos-1; i++) {
                t = s;
                s = s.next;
            }
            if(s.next == null) {
                t.next = null;
            }
            else {
                t.next = s.next;
            }
        }
    }
    
    
}

