
public class Matrix extends Sequence {

    public Sequence s = new Sequence();
    public int r, c;
    
    
    
    public Matrix(int rowsize, int colsize) {
        r = rowsize;
        c = colsize;
        
        Sequence rs = new Sequence();
        Sequence cs = new Sequence();
        for(int i = 0; i < rowsize; i++) {            
            for(int j = 0; j < colsize; j++) {
                cs.data = new MyInteger();
                rs.add(cs.copy(), rs.length());
                cs.next = new Sequence();
                cs = cs.next;
            }
            s.add(rs.copy(), s.length());
            rs.next = new Sequence();
            rs = rs.next;
        }
    }
    
    public void Set(int rowsize, int colsize, int value) {
        Sequence ab = (Sequence)s.index(rowsize);
        Sequence c = (Sequence)ab.index(colsize);
        ((MyInteger)(c.data)).Set(value);
    }
    
    public int Get(int rowsize, int colsize) {
        Sequence ab = (Sequence)s.index(rowsize);
        Sequence c = (Sequence)ab.index(colsize);
        return ((MyInteger)(c.data)).Get();
    }
    
    public Matrix Sum(Matrix mat) {
        if(r != mat.r){
            System.out.println("Matrix dimensions incompatible for Sum");
            System.exit(1);
            }

        if(c != c){
            System.out.println("Matrix dimensions incompatible for Sum");
            System.exit(1);
            }

        Matrix ret = new Matrix(r,c);        
        for(int i = 0; i < r; i++) {

            for(int j = 0; j < c; j++) {
                int a = this.Get(i, j);
                int b = mat.Get(i, j);
                int cc = a + b;
                ret.Set(i,j,cc);                
            }
        }
        return ret;
    }
    
    public Matrix Product(Matrix mat) {
        if(c != mat.r) {
            System.out.println("Matrix dimensions incompatible for Product");
            System.exit(1);
        }
        
        Matrix ret = new Matrix(r,mat.c);    

        for(int i = 0; i < c; i++) {

            for(int j = 0; j < ret.r; j++) {
                int cc = 0;
                for(int g = 0; g < mat.r; g++) {

                    int a = this.Get(i, g);
                    int b = mat.Get(g, j);
                    cc += a*b;
                }
                
                
                ret.Set(i,j,cc);                
            }
        }
        return ret;
    }
    
    public void Print() {
        for(int i = 0; i < r; i++) {
            Sequence ab = ((Sequence)s.index(i)).flatten();
            ab.Print();
            System.out.println();
        }
    }
    
    
}
