/*******************************************/
/**    Your solution goes in this file    **/ 
/*******************************************/

fc_course(X) :-course(X,_,3);course(X,_,4).

prereq_110(X):-imprereq(ecs110,X).
imprereq(X,B) :-course(B,Z,_),member(X,Z).

ecs140a_students(X):-students_in_class(ecs140a,X).
students_in_class(X,B) :-student(B,Z),member(X,Z).

instructor_names(X):- student(john,Y), instructor(X,Z), member(C,Y), member(C,Z).

students(X):-instructor(jim,C),(member(D,C),students_in_class(D,X)).

allprereq([], []) :-!.
allprereq([X|T],B):-course(X,Y,_),allprereq(Y,Z),append(Z,Y,C),allprereq(T,D),append(C,D,B),!.
allprereq(X,B):-allprereq([X],B).


/* part 2 */
all_length([],0):-!.
all_length([H|T],C):-atomic(H),all_length(T,B),C is B+1,!.
all_length([H|T],C):-all_length(H,B),all_length(T,A),C is A+B,!.

swap_prefix_suffix(K, L, S):-same_length(L,S), swapper(K,L,S).
swapper(K,L,S):-append(HL,LT,L),append(K,KT,LT),append(KT,K,LH),append(LH,HL,S).

palin(A):- reverse(A,A).

good(X):-goodHelp(X),!.
goodHelp([0]).
goodHelp([1|T]):- append(A,B,T),goodHelp(A),goodHelp(B).


/* part 3 */

%start state - [Left,Left,Left,Left].
%end state - [Right,Right,Right,Right].


solve :- path(['left','left','left','left'],['right','right','right','right'],[]).

opposite('left','right').
opposite('right','left').
%farmer wolf goat cabbage

safe([F,_,G,_]):- (F = G ),!.
safe([_,W,G,C]):- opposite(W,G), opposite(G,C).
unsafe([F,W,G,C]):-F \= G, (W = G; G = C).

take(_,A,B):-opposite(A,B).

arc(take('none',H,T),[H,W,G,C],[T,W,G,C]):-take(none,H,T).
arc(take('wolf',H,T),[H,H,G,C],[T,T,G,C]):-take(wolf,H,T).
arc(take('goat',H,T),[H,W,H,C],[T,W,T,C]):-take(goat,H,T).
arc(take('cabbage',H,T),[H,W,G,H],[T,W,G,T]):-take(cabbage,H,T).

path(S0,SFinal,L):-
    safe(S0),
    \+ member(S0,L),
    S0 \= SFinal,
    arc(A,S0,S1),
   	\+ member(S1,L),
    safe(S1),
    print(A),nl,
    path(S1,SFinal,[S0|L]).
	

%found solution
path(['right','right','right','right'],SF,L):-
     \+ member(SF,L).
