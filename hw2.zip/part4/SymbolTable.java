import java.util.*;

public class SymbolTable {

	//The symbol table, expressed as a 2-D ArrayList
	//An ArrayList of String ArrayLists
	private ArrayList<ArrayList<String>> st;
	//A blank String ArrayList variable
	//So we don't have to create a variable each time we do a st.get()
	private ArrayList<String> stemp;	
	
	//Current Scope index
	private int tIndex;
	
	//Constructor
	public SymbolTable() {
		st = new ArrayList<ArrayList<String>>();
		stemp = new ArrayList<String>();
		tIndex = -1;
		
	}
	
	//Start a new block, add an empty string arraylist (new scope block) to table, increase current scope
	public void startBlock() {
		ArrayList<String> s = new ArrayList<String>();
		st.add(s);
		tIndex++;
	}
	
	//delete string arraylist (out of scope), decrement current scope
	public void endBlock() {
		st.remove(tIndex);
		tIndex--;
	}
	
	//get current scope
	public int getIndex() {
		return tIndex;
	}
	
	//check any scope
	//Definition check, checks if id defined 
	//return 0 for undefined, 2 for all good;
	public int searchDefine(String id, int table, int lineNum) {
		int t = table;
		if(t > tIndex) {
			error(0, id, lineNum);
		}
		for(;t>=0;t--) {
			stemp = st.get(t);
			if(stemp.contains(id)) {
				return 2;	
			}
		}
		error(0, id, lineNum);
		return 0;
	}
	
	//Java doesn't support default parameters so overloading, basically check current scope
	//Definition check, checks if id defined 
	//return 0 for undefined, 2 for all good;
	public int searchDefine(String id, int lineNum) {
		int t = tIndex;
		for(;t>=0;t--) {
		stemp = st.get(t);
		if(stemp.contains(id)) {
			return 2;	
		}
		}
		error(0, id,lineNum);
		return 0;
	}
	
	//check any scope
	//Declaration check, checks if id declared 
	//return 2 for undeclared, 1 for redeclare;
	public int searchDeclare(String id, int table, int lineNum) {
		int t = table;
		stemp = st.get(t);
		if(stemp.contains(id)) {
			error(1, id,lineNum);
			return 1;
		}
		return 2;
	}
	
	//Declaration check, checks if id declared 
	//return 2 for undeclared, 1 for redeclare;
	public int searchDeclare(String id, int lineNum) {
		int t = tIndex;
		stemp = st.get(t);
		if(stemp.contains(id)) {
			error(1, id, lineNum);
			return 1;
		}
		return 2;
	}
	
	//insert an id into the symbol table
	//checks that id hasn't been previously declared first
	//returns true if not declared before, false if redeclaring because not inserting
	public boolean insert(String str , int lineNum) {
    	if(searchDeclare(str, lineNum) == 2) {
    	stemp = st.get(tIndex);
    	stemp.add(str);
    	st.set(tIndex, stemp);
    	return true;
    	}
    return false;
	}

	
	
	//Called by the searches
	//if err = 0, throws an undeclared var error, closes program
	//if err = 1, throws redeclaration error, continues program
	//if err = 2, continues program
	private void error(int err, String str, int lineNum) {
        if(err == 0){
        System.err.println(str + " is an undeclared variable on line " + lineNum);
        System.exit(1);}
        else if(err == 1){
        System.err.println("redeclaration of variable " + str);}
    }
	
}
