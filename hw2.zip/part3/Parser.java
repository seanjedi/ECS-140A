/* *** This file is given as part of the programming assignment. *** */
import java.util.*;

public class Parser {

	//should all have none to be base case of first function
	//the first() of each non-terminal
	TK F_STMT[] = {TK.TILDE, TK.ID, TK.PRINT, TK.IF, TK.DO, TK.none};
	TK F_PRNT[] = {TK.PRINT, TK.none};
	TK F_ASSN[] = {TK.TILDE, TK.ID, TK.none}; //also rfid has same first
	TK F_DO[] = {TK.DO, TK.none};
	TK F_IF[] = {TK.IF, TK.none};
	TK F_GC[] = {TK.LPAREN, TK.TILDE, TK.ID, TK.NUM, TK.none};
	
	//A symbol table object to be used in parsing
	private SymbolTable st = new SymbolTable();
	
    // tok is global to all these parsing methods;
    // scan just calls the scanner's scan method and saves the result in tok.
    private Token tok; // the current token
    private void scan() {
	tok = scanner.scan();
    }

    private Scan scanner;
    Parser(Scan scanner) {
	this.scanner = scanner;
	scan();
	program();
	if( tok.kind != TK.EOF )
	    parse_error("junk after logical end of program");
    }

    //create block
    private void program() {
	block();
    }

    //Tell the symbol table the scope is being changed, then create the block
    private void block(){
    st.startBlock();
    //what about if no declarations? still works
	declaration_list();
	statement_list();
	//scope ends
	st.endBlock();
    }

    private void declaration_list() {
	// below checks whether tok is in first set of declaration.
	// here, that's easy since there's only one token kind in the set.
	// in other places, though, there might be more.
	// so, you might want to write a general function to handle that.
	while( is(TK.DECLARE) ) {
	    declaration();
	}
    }

    //Declaration rules
    private void declaration() {
	mustbe(TK.DECLARE);
	//Check if ID, then get ID before scanning
	mustCheck(TK.ID);
	st.insert(tok.string, tok.lineNumber);
	scan();
	while( is(TK.COMMA) ) {
	    scan();
	    mustCheck(TK.ID);
		st.insert(tok.string, tok.lineNumber);
		scan();
	}
    }

    //run while is a valid statement
    private void statement_list() {
    	while(first(F_STMT)) {
    		statement();
    	}
    }
    
    //statements uses only or
    //loops from statement_list
    private void statement() {
    	if(first(F_ASSN)) {
    		assignment();
    	}
    	else if(first(F_PRNT)){
    		print();
    	}
    	else if(first(F_DO)) {
    		runDO();
    	}
    	else if(first(F_IF)) {
    		runIF();
    	}
    	else {
    		parse_error("incorrect statement grammar");
    	}
    		
    }
    
    //Print rules
    private void print() {
    	mustbe(TK.PRINT);
    	expr();
    }
    
    //Do rules
    private void runDO() {
    	mustbe(TK.DO);
    	gc();
    	mustbe(TK.ENDDO);
    }
    
    //Guarded_Command rules
    private void gc() {
    	expr();
    	mustbe(TK.THEN);
    	block();
    }
    
    //IF rules
    private void runIF() {
    	mustbe(TK.IF);
    	gc();
    	while(is(TK.ELSEIF)) {
    		scan();
    		gc();
    	}
    	if(is(TK.ELSE)) {
    		scan();
    		block();
    	}
    	mustbe(TK.ENDIF);
    }
    
    //Assignment rules
    private void assignment() {
    	ref_id();
    	mustbe(TK.ASSIGN);
    	expr();
    }
    
    //Ref_ID rules
    private void ref_id() {
    	//Get current scope in num, num2 will be the ~num2 var part
    	int num = st.getIndex();
    	int num2 = 0;
    	if(is(TK.TILDE)) {
    		scan();
    		//if just tilde then scope check is global
    		num = 0;
    		if(is(TK.NUM)) {
    			//reset num to current scope
    			num = st.getIndex();
    			num2 = Integer.parseInt(tok.string);
    			scan();
    		}
    	}
    	//escape num2 blocks out
    	num -= num2;
    	mustCheck(TK.ID);
    	String s = tok.string;
    	//search in the scope to make sure that the id is defined
    	st.searchDefine(s,num, tok.lineNumber);
    	scan();
    }
    
    //EXPR rules
    private void expr() {
    	term();
    	while(is(TK.PLUS) || is(TK.MINUS)) {
    		scan();
    		term();
    	}
    }
    
    //TERM rules
    //same as expr skeleton
    private void term() {
    	factor();
    	while(is(TK.TIMES) || is(TK.DIVIDE)) {
    		scan();
    		factor();
    	}
    }
    
    //Factor rules
    private void factor() {
    	if(is(TK.LPAREN)) {
    		mustbe(TK.LPAREN);
    		expr();
    		mustbe(TK.RPAREN);
    	}
    	//F_ASSN is equivalent to F_REFID so no need to make two identical vars
    	else if(first(F_ASSN)) {
    		ref_id();
    	}
    	else if(is(TK.NUM)) {
    		scan();
    	}
    	else {
    		parse_error("incorrect factor grammar");
    	}
    		
    	
    }

    // is current token what we want?
    // I definitely want it
    private boolean is(TK tk) {
        return tk == tok.kind;
    }
    

    //run through first of a set, check if current tok is in there and isn't none 
    //if found return true else false
    private boolean first(TK[] set) {
        int x = 0;
        while(set[x] != TK.none && set[x] != tok.kind) {
            x++;
        }
        return set[x] != TK.none;
    }


    
    // ensure current token is tk and skip over it.
    private void mustbe(TK tk) {
	if( tok.kind != tk ) {
	    System.err.println( "mustbe: want " + tk + ", got " +
				    tok);
	    parse_error( "missing token (mustbe)" );
	}
	scan();
    }
    
    //mustbe() but without scan so can get token attributes (like name) before scanning
    private void mustCheck(TK tk) {
    	if( tok.kind != tk ) {
    	    System.err.println( "mustCheck: want " + tk + ", got " +
    				    tok);
    	    parse_error( "missing token (mustbe)" );
    	}
        }

    //parsing error, exits with an error (system.exit(1))
    private void parse_error(String msg) {
	System.err.println( "can't parse: line "
			    + tok.lineNumber + " " + msg );
	System.exit(1);
    }
}
